# classData

Data for quantitative and advanced quantitative biology courses

## File descriptions

Descriptions for each of the data sets are provided in learning modules on the course websites for 

BIOL 217:  http://employees.oneonta.edu/stichds/classes/BIOL217/index.html)


BIOL 678:  http://employees.oneonta.edu/stichds/classes/BIOL678/index.html)
